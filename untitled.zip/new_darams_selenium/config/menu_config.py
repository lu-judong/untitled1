#rams指标建模菜单
# rams_title = ['运营数据统计分析系统','RAMS指标建模']
rams_title = ['RAMS指标评估','可靠性参数评估']

# rams立即计算
rams_cal_title = ['运营数据统计分析系统','可靠性快速计算']

#内控模型菜单
incontrol_title = ['运营数据统计分析系统','内控模型配置']





# 修程修制优化分析菜单
repair_title = ['运营数据统计分析系统','修程修制优化分析']

# 技术变更效果评估菜单
tech_title = ['运营数据统计分析系统','技术变更效果评估']

# 单一模型菜单
singelModel_title = ['运营数据统计分析系统','单一模型指标分析']

# 指标对比分析
more_model_title = ['RAMS指标分析','指标对比分析']


# femca菜单
# femca_title = ['运营数据统计分析系统','自动FMECA']
femca_title = ['RAMS指标分析','故障模式影响分析']

#故障占比菜单
# fault_title = ['运营数据统计分析系统','故障占比分析']
fault_title = ['RAMS指标分析','指标占比分析']


#nhpp菜单
# nhpp_title = ['其他功能','NHPP模型']
nhpp_title = ['RAMS特性分析','整车故障趋势分析']

# rcma菜单
# rcma_title = ['RCMA分析系统','RCMA计算']
rcma_title = ['RAMS特性分析','系统部件寿命特性分析']

# 维修性参数评估
main_parameter_title = ['RAMS指标评估','维修性参数评估']

# 自定义选车菜单
custom_car_selection = ['RAMS指标评估','列车分组设置']

# 运维数据清洗菜单
operation_maintenance_data_cleaning = ['RAMS数据维护','运维数据清洗']

# 平均故障间隔菜单
mtbf_contents = ['RAMS计划与验证','平均故障间隔']

# 平均维修时间菜单
mttr_contents = ['RAMS计划与验证','平均维修时间验证']

# 最大维修时间
max_repair_time_title = ['RAMS计划与验证','最大维修时间验证']

# 可靠性增长菜单
taaf_contents = ['RAMS计划与验证','可靠性增长']

# 列车故障信息
train_fault_information_title = ['RAMS数据维护','列车故障信息']

# 智能故障分析
intelligent_fault_analysis = ['RAMS数据维护','智能故障分析']

# 智能故障识别菜单
intelligent_fault_identification = ['RAMS数据维护','智能故障识别']

# RAMS指标追踪
rams_index_tracking_title = ['RAMS指标评估','RAMS指标追踪']

# 维修数据维护菜单
main_data_title = ['其他功能','维修数据维护']




