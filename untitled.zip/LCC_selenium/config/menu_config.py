#通用模型
# common_contents = ['LCC费用统计分析','通用模型']
common_contents = ['通用模型']
# 通用模型图表页面标签栏
common_model_tabs = ['车型维度','高级修维度','维修与检修维度','供应商维度','系统部件维度','生产车间维度']

#敏度分析
sensitivity_contents = ['LCC费用优化及预测','敏度分析']

# 运维费用统计
openx_contents = ['运营费用统计']

# 列车维度占比分析
carload_ratio_contents = ['列车维度','占比分析']

# 列车维度对比分析
carload_compare_contents = ['列车维度','对比分析']

# 路局维度占比分析
railway_ratio_contents = ['站点维度','占比分析']

# 路局维度对比分析
raliway_compare_contents = ['站点维度','对比分析']

# 维修级别/高级修占比分析
senior_ratio_contents = ['维修级别维度','占比分析']

# 维修级别/高级修对比分析
senior_compare_contents = ['维修级别维度','对比分析']

# 供应商占比分析
supplier_ratio_contents = ['供应商维度','占比分析']

# 供应商对比分析
supplier_compare_contents = ['供应商维度','对比分析']

# 系统部件/系统占比分析
system_unit_ratio_contents = ['系统维度','占比分析']

# 系统部件/系统对比分析
system_unit_compare_contents = ['系统维度','对比分析']

# 维修及维修保障维度/维修保障维度占比分析
repair_ratio_contents = ['维修保障维度','占比分析']

# 维修及维修保障维度/维修保障维度对比分析
repair_compare_contents = ['维修保障维度','对比分析']

# 车型维度/车组维度占比分析
cartype_ratio_contents = ['车组维度','占比分析']

# 车型维度/车组维度占比分析
cartype_compare_contents = ['车组维度','对比分析']

# 生产车间/生产线维度/产线维度对比分析
workshop_ratio_contents = ['产线维度','占比分析']

# 生产车间/生产线维度/产线维度对比分析
workshop_compare_contents = ['产线维度','对比分析']

# 工单
work_order = ['工单']

# 自定义选车
customize_train_contents = ['自定义选车']

# 用户系统配置
user_system_settings = ['用户系统配置']

# 内部技术配置
internal_tech_settings = ['内部技术配置']