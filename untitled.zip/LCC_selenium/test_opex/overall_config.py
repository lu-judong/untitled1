# contents = ['全寿命周期费用统计','运维费用统计']
contents = ['LCC费用统计','运营费用统计']
