

overall_cost_joggle = {'overall_list':'http://192.168.1.115:8283/lcc/model/overallRepairCost/list', 'overall_train':'http://192.168.1.115:8283/lcc/basic/cdTrainGroup/trainType'}