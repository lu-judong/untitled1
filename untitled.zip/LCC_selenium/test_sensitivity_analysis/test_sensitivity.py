from bin.add_model_ratio import sensitivity_add
from config.config import *
from config.menu_config import sensitivity_contents

sensitivity_add(url,username,password,sensitivity_contents,modelName,modelCode,'时间',start,end,sen_car,sen_repairlocation)