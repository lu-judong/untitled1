'''
create at 2019/4/26
'''
import time


def bb(arg):
    time.sleep(2)
    return "bb"+str(arg.get("n"))

def dd(arg):
    time.sleep(2)
    return "arg"+str(arg.get("n"))
def ee(arg):
    time.sleep(2)
    return "arg"+str(arg.get("n"))