# 服务器地址
host = '192.168.1.20'
# 服务器账号
user = 'Administrator'
# 服务器密码
password = 'zaq12wsx.'


# localpath = '/data/jenkins/workspace/DARAMS_CORE_T_1/target/darams.war'
# 本机地址
localpath = '/home/darams.war'

# 服务器上传默认地址
remote_default_path = 'F:\\Users\\Administrator'

# 服务器目标地址
remote_purpose_path = 'D:\\tools\\tomcat8.0-2\\webapps'

# Java服务端口号
port = '8083'

# 首页地址
url = 'http://192.168.1.20:8083/darams/a?login'