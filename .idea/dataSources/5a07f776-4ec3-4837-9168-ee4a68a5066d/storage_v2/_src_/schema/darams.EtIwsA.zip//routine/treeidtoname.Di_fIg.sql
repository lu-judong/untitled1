create function treeIdToName(str varchar(2000))
  returns varchar(1000)
  BEGIN
	DECLARE fid VARCHAR (1000) DEFAULT NULL;
	DECLARE result VARCHAR(1000) DEFAULT NULL;
	DECLARE tmpStr VARCHAR (300) DEFAULT NULL;

WHILE str != '' AND str IS NOT NULL DO
	IF LOCATE(',', str) > 0 THEN
		SET fid = SUBSTR(str, 1, LOCATE(',', str)-1);
		SET str = SUBSTR(str, LOCATE(',', str) + 1);
	ELSEIF LENGTH(str) > 0 THEN
		SET fid = str;
		SET str = '';
	END IF;

	SELECT
		t.fault_node INTO tmpStr
	FROM
		cd_fault_object_tree t
	WHERE
		t.id = fid;

	IF result IS NULL THEN
	 SET result = tmpStr;
	ELSE
		SET result = CONCAT_WS("$", result, tmpStr);
	END IF;

END WHILE;

RETURN result;


END;

