create function getParentList(rootId varchar(35))
  returns longtext
  BEGIN 
	DECLARE fid VARCHAR(100) DEFAULT ''; 
	DECLARE str LONGTEXT DEFAULT rootId; 
	DECLARE faultNode VARCHAR(100) DEFAULT '';
	DECLARE parentFaultNodes VARCHAR(1000) DEFAULT '';

	WHILE rootId IS NOT NULL DO 
		SELECT cdfo.id INTO fid FROM cd_fault_object_tree cdfo RIGHT JOIN cd_fault_object_tree cdft ON cdfo.fault_node = cdft.parent_fault_node AND CONCAT(cdfo.parent_fault_nodes,',',cdfo.fault_node) = cdft.parent_fault_nodes WHERE cdft.id = rootId;
		
		IF fid is not null THEN 
			SET str = concat(str, ',', fid); 
		END IF; 
		SET rootId = fid; 
	END WHILE; 
return str;
END;

