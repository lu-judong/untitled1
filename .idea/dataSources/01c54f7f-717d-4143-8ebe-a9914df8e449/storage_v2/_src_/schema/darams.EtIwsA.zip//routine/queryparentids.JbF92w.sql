create function queryParentIds(cid int)
  returns varchar(4000)
  comment '故障对象：根据当前id与关联的parent_id找出当前id的所有上级父节点'
  BEGIN
DECLARE sTemp VARCHAR(4000);
DECLARE sTempParent VARCHAR(4000);

SET sTemp=NULL;
SET sTempParent = CAST(cid AS CHAR);

WHILE sTempParent IS NOT NULL DO
SET sTemp = IFNULL(CONCAT(sTemp,',',sTempParent),sTempParent);
SELECT GROUP_CONCAT(parent_id) INTO sTempParent FROM cd_fault_object WHERE FIND_IN_SET(id,sTempParent)>0;
END WHILE;
RETURN sTemp;
END;

