create procedure update_train_id()
  BEGIN
	DECLARE done INT DEFAULT false;
	DECLARE train_no varchar(50) DEFAULT NULL;
	DECLARE real_fault_object_id varchar(50) DEFAULT null;

	DECLARE cur1 CURSOR FOR
		SELECT
			t.train_no,
			r.real_fault_object_id
		FROM
			op_fault_order_detail d
		INNER JOIN op_train t ON d.id = t.order_detail_id
		INNER JOIN op_fault_real r ON d.id = r.order_detail_id
		group by 
			t.train_no,
			r.real_fault_object_id;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = true;
	open cur1;
		read_loop: LOOP
            FETCH NEXT from cur1 INTO train_no,real_fault_object_id;
            IF done THEN
                LEAVE read_loop;
             END IF;
		update cd_fault_object o set o.train_no_id = (select c.id from cd_train_no c where c.train_no = train_no)
    where o.fault_object_code = real_fault_object_id;
        
    END LOOP;
	CLOSE cur1;

end;

