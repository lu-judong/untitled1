create function nextval(n varchar(50))
  returns int
  BEGIN
	DECLARE
		_cur INT;

SET _cur = (
	SELECT
		current_value
	FROM
		tb_sequence
	WHERE
		NAME = n
);

UPDATE tb_sequence
SET current_value = _cur + increment
WHERE
	NAME = n;

RETURN _cur;

END;

