# 接口状态 正常:normal 改变:change 不存在:non-existent
interface_status = 'normal'