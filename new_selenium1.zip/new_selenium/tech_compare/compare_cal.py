import os
from os import path

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from bin.select_car import deal_car
from config.log_config import logger
import time
from bin.main import Method
from bin.login import Login
from new_selenium.tech_compare.compare_config import *


#技术整改优化效果分析
class Tech:
    def log_file_out(self,msg):
        fo = open(r'.\usecase.txt', mode='a', encoding='utf-8')
        fo.write(msg + '\r\n')
        fo.close()

    def tech_analysis(self,url,username,password,value,select,min_model,time_sleep,wait_time):
        # option = webdriver.ChromeOptions()
        # option.add_argument("headless")
        # driver = webdriver.Chrome(chrome_options=option,                                                                executable_path=r'C:\Users\a\PycharmProjects\untitled\new_selenium\apps\chromedriver.exe')
        path_dir = os.path.dirname(path.dirname(__file__)).replace('\\', '/')
        driver = webdriver.Chrome(executable_path=r'{}/apps/chromedriver.exe'.format(path_dir))
        Login().login(url, username, password, driver)

        self.log_file_out('-----不同平台对比-----')

        for i in contents:
            try:
                Method(driver).contains_xpath('click',i)
                self.log_file_out('点击'+i+'成功')
            except Exception as e:
                logger.debug(e)
                self.log_file_out('点击' + i + '失败')

        time.sleep(time_sleep)
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/moreModel')]"))
            Method(driver).click('id', 'calculate')
            time.sleep(time_sleep)
        except NoSuchElementException as e:
            self.log_file_out('点击不保存计算按钮失败,获取不到相应的xpath')

        Method(driver).switch_out()

        Method(driver).switch_iframe(driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/moreModel/form2?modelType=MORE_MODEL')]"))

        try:
            Method(driver).select_down_list('id', 'modelObject', value)
        except NoSuchElementException as e:
            print('模型录入错误 找不到对应的xpath')
        except:
            print('模型录入数据出错')

        sum1 = 1
        try:
            for x in min_model:
                if len(min_model) == 2:
                    pass
                else:
                    for i in range(0,len(min_model)-2):
                        Method(driver).click('xpath','//*[@id="inputForm"]/a[1]')
                Method(driver).input('id', 'subSetName{}_inp'.format(sum1), x[0])

                try:
                    if select == '里程':
                        Method(driver).click('xpath','//*[@id="subset-{}-left-tab-1"]/a'.format(sum1))
                        Method(driver).input('id','confMileageList{}_startMileage'.format(sum1),x[1])
                        Method(driver).input('id','confMileageList{}_endMileage'.format(sum1),x[2])
                        Method(driver).select_down_list('id','confMileageList{}_averageSpeedSelect'.format(sum1),x[3])

                    elif select == '时间':
                        Method(driver).click('xpath','//*[@id="subSet{}"]/li[2]/div/ul/li[2]/a'.format(sum1))
                        Method(driver).click('xpath','//*[@id="subset-{}-left-tab-2"]/a'.format(sum1))
                        Method(driver).input('id','confDateList[{}].startDate'.format(sum1),x[1])
                        Method(driver).input('id', 'confDateList[{}].endDate'.format(sum1), x[2])
                        Method(driver).select_down_list('id', 'confDateList{}_averageSpeedSelect'.format(sum1), x[3])
                except NoSuchElementException as e:
                    print('新增里程或时间失败')
                try:
                    Method(driver).click('xpath', '//*[@id="subSet{}"]/li[2]/div/ul/li[3]/a'.format(sum1))
                    time.sleep(time_sleep)

                    Method(driver).click('xpath', '//*[@id="subset-{}-left-tab-3"]/a'.format(sum1))
                    time.sleep(time_sleep)

                    Method(driver).click('xpath', '//*[@id="confServiceFaultList{}"]/td[2]/div'.format(sum1))

                    Method(driver).click('xpath', '//*[@id="confServiceFaultList{}"]/td[2]/div/div/ul/li[1]/a'.format(sum1))
                    Method(driver).click('xpath', '//*[@id="confServiceFaultList{}"]/td[2]/div/div/ul/li[2]/a'.format(sum1))
                    Method(driver).click('xpath', '//*[@id="confServiceFaultList{}"]/td[2]/div/div/ul/li[3]/a'.format(sum1))
                    Method(driver).click('xpath', '//*[@id="confServiceFaultList{}"]/td[2]/div'.format(sum1))
                except NoSuchElementException as e:
                    print('服务故障定义选择失败')

                try:
                    Method(driver).click('xpath','//*[@id="subSet{}"]/li[2]/div/ul/li[4]/a'.format(sum1))
                    time.sleep(time_sleep)
                    Method(driver).click('xpath','//*[@id="subset-{}-left-tab-4"]/a'.format(sum1))
                    Method(driver).input('id','confLateHoursList{}_lateHours'.format(sum1),x[4])
                except NoSuchElementException as e:
                    print('晚点时长增加失败')

                Method(driver).click('xpath','//*[@id="subset-{}-right-tab-1"]/a'.format(sum1))

                try:
                    Method(driver).switch_out()
                    b = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
                    Method(driver).switch_iframe('layui-layer-iframe' + b)
                except:
                    print('请录入评估对象')
                    return

                Method(driver).click('xpath','//*[@id="train-group-body"]/table/tbody/tr/td[3]/div/div[1]/div[1]/button[5]')

                time.sleep(5)

                a = deal_car(driver, x[5])
                if a is True:
                    self.log_file_out('选车成功')
                else:
                    self.log_file_out('选车失败')

                    # 故障模式选择页面
                Method(driver).switch_out()
                c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
                Method(driver).switch_iframe('layui-layer-iframe' + c)
                time.sleep(8)
                try:
                    for key in x[6]:
                        if type(x[6][key]).__name__ == 'dict':
                            fault_next_1 = Method(driver).contains_xpath('get', key)
                            Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_1[:-7]))

                            # 取出第二个子节点中的值
                            for i in x[6][key]:
                                if type(x[6][key][i]).__name__ == 'dict':
                                    fault_next_2 = Method(driver).contains_xpath('get', i)
                                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_2[:-7]))

                                    # 取出第三个子节点的值
                                    for m in x[6][key][i]:
                                        if type(x[6][key][i][m]).__name__ == 'dict':
                                            fault_next_3 = Method(driver).contains_xpath('get', m)
                                            Method(driver).click('xpath',
                                                                 '//*[@id= \'{}\']/i'.format(fault_next_3[:-7]))
                                            # 取出第四个子节点的值
                                            for j in x[6][key][i][m]:
                                                if x[6][key][i][m][j] == 'all':
                                                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(j))
                                                    Method(driver).click('name', 'btSelectAll')
                                                    Method(driver).click('xpath', '//*[@id="right-move"]')
                                                else:
                                                    fault_next_4 = Method(driver).contains_xpath('get', j)
                                                    Method(driver).click('xpath',
                                                                         '//*[@id= \'{}\']/i'.format(fault_next_4[:-7]))
                                                    time.sleep(time_sleep)
                                                    for p in x[6][key][i][m][j]:
                                                        driver.find_element_by_xpath(
                                                            "//td[contains(text(),\'{}\')]/../td[1]/input".format(
                                                                p)).click()
                                                        Method(driver).click('xpath', '//*[@id="right-move"]')

                                        else:
                                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(m))
                                            time.sleep(time_sleep)
                                            if x[6][key][i][m] == 'all':
                                                Method(driver).click('name', 'btSelectAll')
                                                Method(driver).click('xpath', '//*[@id="right-move"]')
                                            else:
                                                for k in x[6][key][i][m]:
                                                    driver.find_element_by_xpath(
                                                        "//td[contains(text(),\'{}\')]/../td[1]/input".format(
                                                            k)).click()
                                                Method(driver).click('xpath', '//*[@id="right-move"]')
                                else:
                                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(i))
                                    time.sleep(time_sleep)
                                    if x[6][key][i] == 'all':
                                        Method(driver).click('name', 'btSelectAll')
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                                    else:
                                        for n in x[6][key][i]:
                                            driver.find_element_by_xpath(
                                                "//td[contains(text(),\'{}\')]/../td[1]/input".format(n)).click()
                                            time.sleep(time_sleep)
                                        Method(driver).click('xpath', '//*[@id="right-move"]')

                        else:
                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(key))
                            time.sleep(time_sleep)
                            if x[6][key] == 'all':
                                Method(driver).click('name', 'btSelectAll')
                                Method(driver).click('xpath', '//*[@id="right-move"]')
                            else:
                                for i in x[6][key]:
                                    # WebDriverWait(driver, 10).until(EC.element_to_be_clickable(By.XPATH, "//td[contains(text(),\'{}\')]/../td[1]/input".format(i))).click()
                                    driver.find_element_by_xpath(
                                        "//td[contains(text(),\'{}\')]/../td[1]/input".format(i)).click()
                                Method(driver).click('xpath', '//*[@id="right-move"]')
                    self.log_file_out('故障模型选择成功')
                except NoSuchElementException as e:
                    logger.error('xpath' + '不存在!')
                    self.log_file_out('故障模型选择失败')


                try:
                    driver.execute_script('top.$(".layui-layer-btn2")[1].click()')
                except NoSuchElementException as e:
                    logger.error('xpath' + '不存在!')
                    self.log_file_out('点击确定按钮失败')
                except:
                    print('请录入完整的模型')
                    return

                Method(driver).switch_out()
                Method(driver).switch_iframe(driver.find_element_by_xpath(
                    "//iframe[contains(@src,'/darams/a/mould/moreModel/form2?modelType=MORE_MODEL')]"))
                sum1 += 1
        except:
            print('录入模型错误')

        try:
            Method(driver).switch_out()

            Method(driver).click('class', 'layui-layer-btn0')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在!')
            self.log_file_out('点击计算按钮失败')
        except:
            print('请录入正确的模型')
            return

        time.sleep(wait_time)

        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/moreModel/charts?modelId=moremodelcalculate')]"))
            time.sleep(time_sleep)
            logger.debug('图表页面获取成功')
            self.log_file_out('图表页面获取成功')
        except NoSuchElementException as e:
            self.log_file_out('图表页面获取失败')
        except:
            print('图表页面获取失败')



# min_model = [['m1', '0', '100',2, 3,{'E05': ['2091', '2092']},{'高压供电系统': 'all'}], ['m2', '100', '200', 2,3,{'E05': ['2091', '2092']},{'高压供电系统': 'all'}]]
#
#
# url = 'http://192.168.1.115:9092/darams/a?login'
#
#
# time_sleep = 2
# wait_time = 10
#
#
# Tech().tech_analysis(url,1,'里程',min_model,time_sleep,wait_time)