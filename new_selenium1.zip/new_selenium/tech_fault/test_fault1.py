import os
from os import path

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException,WebDriverException
import requests
from config.log_config import logger
import time
from bin.main import Method
from bin.login import Login
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from new_selenium.tech_fault.fault_config import *
from bin.select_car import deal_car



#故障占比分析
class Tech:
    def log_file_out(self, msg):
        fo = open(r'.\usecase.txt', mode='a', encoding='utf-8')
        fo.write(msg + '\r\n')
        fo.close()

    def tech_fault_analysis(self,url,username,password,modelCode,modelName,value,remarks,start,end,average,t,car,fault,time_sleep,wait_time):
        #
        # option = webdriver.ChromeOptions()
        # option.add_argument("headless")
        # driver = webdriver.Chrome(chrome_options=option,
        #                           executable_path=r'C:\Users\a\PycharmProjects\untitled\new_selenium\apps\chromedriver.exe')
        path_dir = os.path.dirname(path.dirname(__file__)).replace('\\', '/')
        driver = webdriver.Chrome(executable_path=r'{}/apps/chromedriver.exe'.format(path_dir))
        Login().login(url, username, password,driver)
        self.log_file_out('-----故障占比分析-----')

        for i in contents:
            try:
                Method(driver).contains_xpath('click',i)
                self.log_file_out('点击'+i+'成功')
            except Exception as e:
                logger.debug(e)
                self.log_file_out('点击' + i + '失败')

        time.sleep(time_sleep)
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/analysisProportion')]"))
            Method(driver).click('xpath','//*[@id="add"]')
            time.sleep(time_sleep)
        except NoSuchElementException as e:
            self.log_file_out('点击新建按钮失败 找不到对应的xpath')

        Method(driver).switch_out()
        a = Method(driver).get_attr('css',"[class='layui-layer layui-layer-iframe']",'times')
        Method(driver).switch_iframe('layui-layer-iframe' + a)

        try:
            Method(driver).input('id', 'modelCode', modelCode)
            Method(driver).input('id', 'modelName', modelName)
            Method(driver).select_down_list('id','modelObject',value)
            if remarks == '':
                pass
            else:
                Method(driver).input('xpath','//*[@id="remarks"]',remarks)
            self.log_file_out('模型构建成功')
        except Exception as e:
            logger.debug(e)
            self.log_file_out('模型构建失败')

        # 新增里程
        try:
            Method(driver).click('xpath','//*[@id="left-tab-1"]/a')
            Method(driver).input('xpath','//*[@id="confMileageList0_startMileage"]',start)
            Method(driver).input('xpath','//*[@id="confMileageList0_endMileage"]',end)
            Method(driver).select_down_list('xpath','//*[@id="confMileageList0_averageSpeedSelect"]',average)
            self.log_file_out('新增里程成功')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在！')
            self.log_file_out('新增里程失败')

        time.sleep(1)
        # 服务故障定义
        try:
            Method(driver).click('xpath','//*[@id="inputForm"]/div[1]/ul/li[3]/a')
            time.sleep(time_sleep)
            Method(driver).click('xpath','//*[@id="left-tab-3"]/a')
            time.sleep(time_sleep)
            Method(driver).click('xpath','//*[@id="confServiceFaultList0"]/td[2]/div/button')

            Method(driver).click('xpath','//*[@id="confServiceFaultList0"]/td[2]/div/div/ul/li[1]/a')
            Method(driver).click('xpath','//*[@id="confServiceFaultList0"]/td[2]/div/div/ul/li[2]/a')
            Method(driver).click('xpath','//*[@id="confServiceFaultList0"]/td[2]/div/div/ul/li[3]/a')
            self.log_file_out('服务故障定义输入成功')
        except NoSuchElementException as e:
            logger.error('xpath'+'找不到')
            self.log_file_out('服务故障定义输入失败')

        # 晚点时长
        try:
            Method(driver).click('xpath','//*[@id="inputForm"]/div[1]/ul/li[4]/a')
            time.sleep(time_sleep)
            Method(driver).click('xpath','//*[@id="left-tab-4"]/a')
            Method(driver).input('xpath','//*[@id="confLateHoursList0_lateHours"]',t)
            self.log_file_out('晚点时长输入成功')
            # 车型车号新增
            Method(driver).click('xpath','//*[@id="right-tab-1"]/a')
            time.sleep(time_sleep)
        except NoSuchElementException as e:
            logger.debug('xpath找不到')

        # 从新进入新打开的iframe 先去最外层 在进入打开的iframe
        try:
            Method(driver).switch_out()
            b = Method(driver).get_attr('css',"[class='layui-layer layui-layer-iframe my-skin']", 'times')
            Method(driver).switch_iframe('layui-layer-iframe' + b)
        except:
            print('请录入评估对象')
            return
        time.sleep(5)

        a = deal_car(driver,car)
        if a is True:
            self.log_file_out('选车成功')
        else:
            self.log_file_out('选车失败')


        # 故障模式选择页面
        Method(driver).switch_out()
        c = Method(driver).get_attr('css',"[class='layui-layer layui-layer-iframe my-skin']", 'times')
        Method(driver).switch_iframe('layui-layer-iframe' + c)
        time.sleep(5)
        try:
            for key in fault:
                if type(fault[key]).__name__ == 'dict':
                    fault_next_1 = Method(driver).contains_xpath('get', key)
                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_1[:-7]))

                    # 取出第二个子节点中的值
                    for i in fault[key]:
                        if type(fault[key][i]).__name__ == 'dict':
                            fault_next_2 = Method(driver).contains_xpath('get',i)
                            Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_2[:-7]))

                            # 取出第三个子节点的值
                            for m in fault[key][i]:
                                if type(fault[key][i][m]).__name__ == 'dict':
                                    fault_next_3 = Method(driver).contains_xpath('get', m)
                                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_3[:-7]))
                                    # 取出第四个子节点的值
                                    for j in fault[key][i][m]:
                                        if fault[key][i][m][j] == 'all':
                                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(j))
                                            Method(driver).click('name', 'btSelectAll')
                                            Method(driver).click('xpath', '//*[@id="right-move"]')
                                        else:
                                            fault_next_4 = Method(driver).contains_xpath('get', j)
                                            Method(driver).click('xpath',
                                                                 '//*[@id= \'{}\']/i'.format(fault_next_4[:-7]))
                                            time.sleep(time_sleep)
                                            for p in fault[key][i][m][j]:
                                                driver.find_element_by_xpath(
                                                    "//td[contains(text(),\'{}\')]/../td[1]/input".format(p)).click()
                                                Method(driver).click('xpath', '//*[@id="right-move"]')

                                else:
                                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(m))
                                    time.sleep(time_sleep)
                                    if fault[key][i][m] == 'all':
                                        Method(driver).click('name', 'btSelectAll')
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                                    else:
                                        for k in fault[key][i][m]:
                                            driver.find_element_by_xpath(
                                                "//td[contains(text(),\'{}\')]/../td[1]/input".format(k)).click()
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                        else:
                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(i))
                            time.sleep(time_sleep)
                            if fault[key][i] == 'all':
                                Method(driver).click('name', 'btSelectAll')
                                Method(driver).click('xpath', '//*[@id="right-move"]')
                            else:
                                for n in fault[key][i]:
                                    driver.find_element_by_xpath(
                                        "//td[contains(text(),\'{}\')]/../td[1]/input".format(n)).click()
                                    time.sleep(time_sleep)
                                Method(driver).click('xpath', '//*[@id="right-move"]')

                else:
                    Method(driver).click('xpath','//*[text()=\'{}\']'.format(key))
                    time.sleep(time_sleep)
                    if fault[key] == 'all':
                        Method(driver).click('name','btSelectAll')
                        Method(driver).click('xpath', '//*[@id="right-move"]')
                    else:
                        for i in fault[key]:
                            # WebDriverWait(driver, 10).until(EC.element_to_be_clickable(By.XPATH, "//td[contains(text(),\'{}\')]/../td[1]/input".format(i))).click()
                            driver.find_element_by_xpath("//td[contains(text(),\'{}\')]/../td[1]/input".format(i)).click()
                        Method(driver).click('xpath','//*[@id="right-move"]')
            self.log_file_out('故障模型选择成功')
        except NoSuchElementException as e:
            logger.error('xpath'+'不存在!')
            self.log_file_out('故障模型选择失败')

        try:
            Method(driver).switch_out()
            # d = "layui_layer" + c
            # e = "layui_layer" + str((int(c)-1))
            # Method(driver).click('xpath','//*[@id=\'%s\']/div[3]/a[3]' % d)
            Method(driver).click('class','layui-layer-btn2')
            #点击保存按钮
            time.sleep(time_sleep)
            # Method(driver).click('xpath','//*[@id=\'%s\']/div[3]/a[1]' % e)
            Method(driver).click('class','layui-layer-btn0')
        except NoSuchElementException as e:
            logger.error('xpath'+'不存在!')
            self.log_file_out('点击保存按钮失败')


        Method(driver).switch_out()
        Method(driver).switch_iframe(
            driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/analysisProportion')]"))
        time.sleep(1)

        try:
            driver.find_element_by_xpath("//a[contains(text(),\'{}\')]/../../td[8]/a[3]".format(modelCode)).click()
        except WebDriverException:
            print('请录入正确的模型')
            return
        except NoSuchElementException:
            print('点击图表按钮失败')

        if driver.find_element_by_xpath("//a[contains(text(),\'{}\')]/../../td[5]".format(modelCode)).text == '计算异常':
            self.log_file_out('计算异常,无法打开图表页面')
        else:
            try:
                a = WebDriverWait(driver, wait_time).until(EC.text_to_be_present_in_element((By.XPATH, "//a[contains(text(),\'{}\')]/../../td[5]".format(modelCode)), u'计算完成'))
                if a is True:
                    logger.debug('评估成功')
                    driver.find_element_by_xpath("//a[contains(text(),\'{}\')]/../../td[8]/a[4]".format(modelCode)).click()

                    # 查看点击图表出来的页面是否存在
                    Method(driver).switch_out()
                    c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
                    try:
                        next_url = Method(driver).get_attr('id', 'layui-layer-iframe' + c, 'src')
                        status = requests.get(next_url).status_code
                        if status == 200:
                            logger.debug('图表页面获取成功')
                            self.log_file_out('图表页面获取成功')
                        elif status == 404:
                            logger.error('{}请求404'.format(next_url))
                            self.log_file_out('图表页面获取失败')
                    except Exception as e:
                        logger.error(e)

            except Exception as e:
                logger.debug('评估时间太长,评估失败')
                self.log_file_out('评估时间太长,评估失败')
# url = 'http://192.168.1.115:9092/darams/a?login'
# car = {
#     'E01': ['2001']
# }
#
# fault_pattern = {'高压供电系统':'all'}
#
# fault_object = {
#     '高压供电系统':{'高压电缆、连接器及跳线':['电缆']},
#     '辅助供电系统':['刮雨器电源'],
#     '门窗系统':'all'
# }
#
# time_sleep = 3
# wait_time = 10
#
# Tech().tech_fault_analysis(url,'数据测试2','数据测试2',1,'','0','100',1,'3',car,fault_pattern,time_sleep,wait_time)
