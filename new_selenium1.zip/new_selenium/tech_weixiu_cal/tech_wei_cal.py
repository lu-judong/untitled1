import os
from os import path

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException,WebDriverException
import requests
from config.log_config import logger
import time
from bin.main import Method
from bin.login import Login
from new_selenium.tech_weixiu_cal.weixiu_config import *
from selenium.webdriver.support.ui import Select
from bin.select_car import deal_car


#维修规程优化效果分析
class test_technology:
    def log_file_out(self,msg):
        fo = open(r'./usecase.txt', mode='a', encoding='utf-8')
        fo.write(msg + '\r\n')
        fo.close()


    # 检查RAMS运营数据分析
    def tech(self,url,username,password,value,start,end,end1,car,fault,time_sleep,wait_time):

        # option = webdriver.ChromeOptions()
        # option.add_argument("headless")
        # driver = webdriver.Chrome(chrome_options=option
        # ,executable_path=r'C:\Users\a\PycharmProjects\untitled\new_selenium\apps\chromedriver.exe'
        #  )
        # driver.maximize_window()
        path_dir = os.path.dirname(path.dirname(__file__)).replace('\\', '/')
        driver = webdriver.Chrome(executable_path=r'{}/apps/chromedriver.exe'.format(path_dir))

        self.log_file_out('-----修程修制立即计算-----')
        Login().login(url,username,password,driver)


        for i in contents:
            try:
                Method(driver).contains_xpath('click',i)
                self.log_file_out('点击'+i+'成功')
            except Exception as e:
                logger.debug(e)
                self.log_file_out('点击' + i + '失败')
        time.sleep(time_sleep)
        # 点击新建得到弹框
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/repairProcedure')]"))
            Method(driver).click('id', 'calculate')
            time.sleep(time_sleep)
        except NoSuchElementException as e:
            self.log_file_out('点击新建按钮失败,未找到立即计算按钮的xpath')

        Method(driver).switch_out()
        a = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
        Method(driver).switch_iframe('layui-layer-iframe' + a)

        try:
            Method(driver).select_down_list('id', 'modelObject', value)
            Method(driver).input('id','confMileageList0_startMileage',start)
            Method(driver).input('id','confMileageList0_endMileage',end)
            Method(driver).input('id','confMileageList1_endMileage',end1)
        except NoSuchElementException as e:
            print('模型录入错误 找不到对应的xpath')
        except:
            print('模型录入数据出错')

        if Select(driver.find_element_by_id('averageSpeedSelect')).first_selected_option.text == '260':
            print('平均时速默认值正确')
        else:
            print('平均时速默认值不正确')

        if driver.find_element_by_css_selector("[class='filter-option pull-left']").text== driver.find_element_by_css_selector("[class='btn dropdown-toggle btn-default']").get_attribute('title'):
            print('服务故障定义默认值正确')
        else:
            print('服务故障定义默认值不正确')

        if driver.find_element_by_id('confLateHoursList0_lateHours').get_attribute('value') == '3':
            print('晚点时长默认正确')
        else:
            print('晚点时长默认不正确')


        try:
            Method(driver).contains_xpath('click','新增')
        except NoSuchElementException as e:
            print('点击新建按钮失败')

        try:
            Method(driver).switch_out()
            b = Method(driver).get_attr('css',"[class='layui-layer layui-layer-iframe my-skin']", 'times')
            Method(driver).switch_iframe('layui-layer-iframe' + b)
        except:
            print('请录入评估对象')
            return

        time.sleep(time_sleep)

        # 车型 车号新增页面
        a = deal_car(driver, car)
        if a is True:
            self.log_file_out('选车成功')
        else:
            self.log_file_out('选车失败')

        # 故障模式选择页面
        Method(driver).switch_out()
        c = Method(driver).get_attr('css',"[class='layui-layer layui-layer-iframe my-skin']", 'times')
        Method(driver).switch_iframe('layui-layer-iframe' + c)
        time.sleep(time_sleep)
        try:
            for key in fault:
                if type(fault[key]).__name__ == 'dict':
                    fault_next_1 = Method(driver).contains_xpath('get', key)
                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_1[:-7]))

                    # 取出第二个子节点中的值
                    for i in fault[key]:
                        if type(fault[key][i]).__name__ == 'dict':
                            fault_next_2 = Method(driver).contains_xpath('get',i)
                            Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_2[:-7]))

                            # 取出第三个子节点的值
                            for m in fault[key][i]:
                                if type(fault[key][i][m]).__name__ == 'dict':
                                    fault_next_3 = Method(driver).contains_xpath('get', m)
                                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_3[:-7]))
                                    # 取出第四个子节点的值
                                    for j in fault[key][i][m]:
                                        if fault[key][i][m][j] == 'all':
                                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(j))
                                            Method(driver).click('name', 'btSelectAll')
                                            Method(driver).click('xpath', '//*[@id="right-move"]')
                                        else:
                                            fault_next_4 = Method(driver).contains_xpath('get', j)
                                            Method(driver).click('xpath',
                                                                 '//*[@id= \'{}\']/i'.format(fault_next_4[:-7]))
                                            time.sleep(time_sleep)
                                            for p in fault[key][i][m][j]:
                                                driver.find_element_by_xpath(
                                                    "//td[contains(text(),\'{}\')]/../td[1]/input".format(p)).click()
                                                Method(driver).click('xpath', '//*[@id="right-move"]')

                                else:
                                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(m))
                                    time.sleep(time_sleep)
                                    if fault[key][i][m] == 'all':
                                        Method(driver).click('name', 'btSelectAll')
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                                    else:
                                        for k in fault[key][i][m]:
                                            driver.find_element_by_xpath(
                                                "//td[contains(text(),\'{}\')]/../td[1]/input".format(k)).click()
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                        else:
                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(i))
                            time.sleep(time_sleep)
                            if fault[key][i] == 'all':
                                Method(driver).click('name', 'btSelectAll')
                                Method(driver).click('xpath', '//*[@id="right-move"]')
                            else:
                                for n in fault[key][i]:
                                    driver.find_element_by_xpath(
                                        "//td[contains(text(),\'{}\')]/../td[1]/input".format(n)).click()
                                    time.sleep(time_sleep)
                                Method(driver).click('xpath', '//*[@id="right-move"]')

                else:
                    Method(driver).click('xpath','//*[text()=\'{}\']'.format(key))
                    time.sleep(time_sleep)
                    if fault[key] == 'all':
                        Method(driver).click('name','btSelectAll')
                        Method(driver).click('xpath', '//*[@id="right-move"]')
                    else:
                        for i in fault[key]:
                            # WebDriverWait(driver, 10).until(EC.element_to_be_clickable(By.XPATH, "//td[contains(text(),\'{}\')]/../td[1]/input".format(i))).click()
                            driver.find_element_by_xpath("//td[contains(text(),\'{}\')]/../td[1]/input".format(i)).click()
                        Method(driver).click('xpath','//*[@id="right-move"]')
            self.log_file_out('故障模型选择成功')
        except NoSuchElementException as e:
            logger.error('xpath'+'不存在!')
            self.log_file_out('故障模型选择失败')

        try:
            Method(driver).switch_out()
            Method(driver).click('class', 'layui-layer-btn2')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在!')
            self.log_file_out('点击确定按钮失败')
        except:
            print('请录入完整的模型')
            return


        time.sleep(time_sleep)
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/disposableModel/repairProcedureForm')]"))
            Method(driver).click('id', 'calculate')
            print('点击计算按钮成功')
        except NoSuchElementException:
            print('点击计算按钮失败')
        except:
            print('模型录入失败')

        time.sleep(wait_time)

        Method(driver).switch_out()
        try:
            c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
        except NoSuchElementException as e:
            print('请录入正确的模型')
            return

        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/disposableModel/repairProcedureView')]"))
            time.sleep(time_sleep)
            logger.debug('图表页面获取成功')
            self.log_file_out('图表页面获取成功')
        except NoSuchElementException as e:
            self.log_file_out('图表页面获取失败')
        except:
            print('图表页面获取失败')
# url = 'http://192.168.1.115:9092/darams/a?login'
# car = {
#     'E03': ['2121','2122']
# }
#
# fault_pattern = {'高压供电系统':['受电弓']}
#
#
#
# time_sleep = 3
# wait_time = 10
#
#
# test_technology().tech(url,1,'180','200','300',car,fault_pattern,time_sleep,wait_time)