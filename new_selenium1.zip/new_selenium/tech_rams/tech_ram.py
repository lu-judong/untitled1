import os
from os import path

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
import requests
from config.log_config import logger
import time
from bin.main import Method
from bin.login import Login
from new_selenium.tech_rams.rams_config import *
from selenium.webdriver.support.ui import Select



class Tech:
    def log_file_out(self, msg):
        fo = open(r'.\usecase.txt', mode='a', encoding='utf-8')
        fo.write(msg + '\r\n')
        fo.close()

    def tech_fault_analysis(self,url,username,password,value,value1,start,end,car,fault,time_sleep,wait_time):
        #
        # option = webdriver.ChromeOptions()
        # option.add_argument("headless")
        # driver = webdriver.Chrome(chrome_options=option,
        #                           executable_path=r'C:\Users\a\PycharmProjects\untitled\new_selenium\apps\chromedriver.exe')
        path_dir = os.path.dirname(path.dirname(__file__)).replace('\\', '/')
        driver = webdriver.Chrome(executable_path=r'{}/apps/chromedriver.exe'.format(path_dir))
        Login().login(url,username,password,driver)

        self.log_file_out('-----RAMS指标评估-----')

        for i in contents:
            try:
                Method(driver).contains_xpath('click',i)
                self.log_file_out('点击'+i+'成功')
            except Exception as e:
                logger.debug(e)
                self.log_file_out('点击' + i + '失败')

        time.sleep(time_sleep)
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/disposableModel/form')]"))
            time.sleep(time_sleep)
        except NoSuchElementException as e:
            self.log_file_out('切入iframe失败')


        if Select(driver.find_element_by_id('confMileageSelect')).first_selected_option.text == '里程':
            print('里程/日期框正确')
        else:
            print('里程/日期框错误')

        if Select(driver.find_element_by_id('confMileageList0_averageSpeedSelect')).first_selected_option.text == '260':
            print('平均时速默认值正确')
        else:
            print('平均时速默认值不正确')

        if driver.find_element_by_css_selector("[class='filter-option pull-left']").text== driver.find_element_by_css_selector("[class='btn dropdown-toggle btn-default']").get_attribute('title'):
            print('服务故障定义默认值正确')
        else:
            print('服务故障定义默认值不正确')

        if driver.find_element_by_id('confLateHoursList0_lateHours').get_attribute('value') == '3':
            print('晚点时长默认正确')
        else:
            print('晚点时长默认不正确')


        try:
            Method(driver).select_down_list('id', 'modelObject', value)
            if value1 == '里程':
                Method(driver).input('id', 'confMileageList0_startMileage', start)
                Method(driver).input('id', 'confMileageList0_endMileage', end)
            elif value1 == '时间':
                time.sleep(time_sleep)
                Method(driver).select_down_list('id','confMileageSelect',1)
                time.sleep(time_sleep)
                Method(driver).input('name', 'confDateList[0].startDate', start)
                Method(driver).input('name', 'confDateList[0].endDate', end)

        except NoSuchElementException as e:
            print('模型基本信息输入失败')
        except:
            print('请录入评估对象')
            return

        try:
            Method(driver).contains_xpath('click','新增')
        except NoSuchElementException as e:
            print('点击新建按钮失败')

        try:
            Method(driver).switch_out()
            b = Method(driver).get_attr('css',"[class='layui-layer layui-layer-iframe my-skin']", 'times')
            Method(driver).switch_iframe('layui-layer-iframe' + b)
        except:
            print('请录入评估对象')
            return

        time.sleep(time_sleep)

        # 车型 车号新增页面
        try:
            for x in car:
                driver.find_element_by_xpath(
                    "//span[@class='train zoomIn' and contains(text(),\'{}\')]".format(x)).click()
                car_num = car.get(x)
                time.sleep(2)
                for i in car_num:
                    # driver.find_element_by_xpath("//span[contains(text(),\'{}\')]".format(i)).click()
                    car_num = driver.find_element_by_xpath(
                        '//span[contains(text(),\'{}\')]/..'.format(i)).get_attribute('id')

                    js = 'top.checked(top.$("#{}"))'.format(car_num)
                    driver.execute_script(js)

                    # time.sleep(2)
                driver.execute_script('top.$(".layui-layer-btn0")[1].click()')
                time.sleep(2)
            Method(driver).switch_out()
            # 这个可以点击得元素失去焦点
            # Message: unknown error: Element <a class="layui-layer-btn1">...</a> is not clickable at point (975, 498). Other element would receive the click: <a class="layui-layer-btn3">...</a>
            # Method(driver).two_element_click("[class='layui-layer-btn layui-layer-btn-']",'layui-layer-btn1')
            Method(driver).two_element_click("[class='layui-layer layui-layer-iframe my-skin']", 'layui-layer-btn1')
            self.log_file_out('选车成功')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在!')
            self.log_file_out('选车失败')


        # 故障模式选择页面
        Method(driver).switch_out()
        c = Method(driver).get_attr('css',"[class='layui-layer layui-layer-iframe my-skin']", 'times')
        Method(driver).switch_iframe('layui-layer-iframe' + c)
        time.sleep(time_sleep)
        try:
            for key in fault:
                if type(fault[key]).__name__ == 'dict':
                    fault_next_1 = Method(driver).contains_xpath('get', key)
                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_1[:-7]))

                    # 取出第二个子节点中的值
                    for i in fault[key]:
                        if type(fault[key][i]).__name__ == 'dict':
                            fault_next_2 = Method(driver).contains_xpath('get',i)
                            Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_2[:-7]))

                            # 取出第三个子节点的值
                            for m in fault[key][i]:
                                if type(fault[key][i][m]).__name__ == 'dict':
                                    fault_next_3 = Method(driver).contains_xpath('get', m)
                                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_3[:-7]))
                                    # 取出第四个子节点的值
                                    for j in fault[key][i][m]:
                                        if fault[key][i][m][j] == 'all':
                                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(j))
                                            Method(driver).click('name', 'btSelectAll')
                                            Method(driver).click('xpath', '//*[@id="right-move"]')
                                        else:
                                            fault_next_4 = Method(driver).contains_xpath('get', j)
                                            Method(driver).click('xpath',
                                                                 '//*[@id= \'{}\']/i'.format(fault_next_4[:-7]))
                                            time.sleep(time_sleep)
                                            for p in fault[key][i][m][j]:
                                                driver.find_element_by_xpath(
                                                    "//td[contains(text(),\'{}\')]/../td[1]/input".format(p)).click()
                                                Method(driver).click('xpath', '//*[@id="right-move"]')

                                else:
                                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(m))
                                    time.sleep(time_sleep)
                                    if fault[key][i][m] == 'all':
                                        Method(driver).click('name', 'btSelectAll')
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                                    else:
                                        for k in fault[key][i][m]:
                                            driver.find_element_by_xpath(
                                                "//td[contains(text(),\'{}\')]/../td[1]/input".format(k)).click()
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                        else:
                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(i))
                            time.sleep(time_sleep)
                            if fault[key][i] == 'all':
                                Method(driver).click('name', 'btSelectAll')
                                Method(driver).click('xpath', '//*[@id="right-move"]')
                            else:
                                for n in fault[key][i]:
                                    driver.find_element_by_xpath(
                                        "//td[contains(text(),\'{}\')]/../td[1]/input".format(n)).click()
                                    time.sleep(time_sleep)
                                Method(driver).click('xpath', '//*[@id="right-move"]')

                else:
                    Method(driver).click('xpath','//*[text()=\'{}\']'.format(key))
                    time.sleep(time_sleep)
                    if fault[key] == 'all':
                        Method(driver).click('name','btSelectAll')
                        Method(driver).click('xpath', '//*[@id="right-move"]')
                    else:
                        for i in fault[key]:
                            # WebDriverWait(driver, 10).until(EC.element_to_be_clickable(By.XPATH, "//td[contains(text(),\'{}\')]/../td[1]/input".format(i))).click()
                            driver.find_element_by_xpath("//td[contains(text(),\'{}\')]/../td[1]/input".format(i)).click()
                        Method(driver).click('xpath','//*[@id="right-move"]')
            self.log_file_out('故障模型选择成功')
        except NoSuchElementException as e:
            logger.error('xpath'+'不存在!')
            self.log_file_out('故障模型选择失败')

        try:
            Method(driver).switch_out()
            Method(driver).click('class', 'layui-layer-btn2')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在!')
            self.log_file_out('点击确定按钮失败')
        except:
            self.log_file_out('请录入完整的模型')
            return


        time.sleep(time_sleep)
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/disposableModel/form')]"))
            Method(driver).click('id', 'calculate')
            self.log_file_out('点击计算按钮成功')
        except:
            self.log_file_out('点击计算按钮失败')

        time.sleep(wait_time)
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/disposableModel/data_view')]"))
            driver.maximize_window()
            Method(driver).click('id','tab-1-chart1')
        except:
            self.log_file_out('请输入正确的模型')
            return

        try:
            js = 'var aa = echarts.getInstanceByDom($("#tab-1-chart1")[0]);' \
                  'var option = aa.getOption();' \
                  ' option.series[3].data.forEach((item,index)=>{' \
                  'if( item != "NaN"){' \
                  'var param = {componentType:"series",name:option.xAxis[0].data[index],seriesName:"关联故障",seriesType:"line",value:option.series[3].data[index]};' \
                 'var lineType = param.seriesName, x = param.name, y = param.value;' \
                 '''var faultIds = globalDataSet["tab-1-chart1"][lineType][x][y].faultIds.split(',');''' \
                  "if (faultIds != null && faultIds != '' && faultIds.length > 0) {" \
                  'skipToFautlOrder(faultIds);' \
                  'return false;' \
                  '}' \
                  '}})'
            driver.execute_script(js)
        except:
            self.log_file_out('点击图表失败')

        time.sleep(3)
        Method(driver).switch_out()
        Method(driver).two_element_click("[class='layui-layer layui-layer-page']", 'layui-layer-ico')

        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/disposableModel/data_view')]"))
        except:
            return
        time.sleep(3)

        try:
            Method(driver).click('xpath','/html/body/div/ul/li[2]/a')
            time.sleep(2)
            Method(driver).click('id', 'tab-2-chart1')
            self.log_file_out('点击单一模型指标分析图表成功')
        except:
            self.log_file_out('点击单一模型指标分析图表失败')
        try:
            js1 = 'var aa = echarts.getInstanceByDom($("#tab-2-chart1")[0]);' \
                 'var option = aa.getOption();' \
                 ' option.series[8].data.forEach((item,index)=>{' \
                 'if( item != "NaN"){' \
                 'var param = {componentType:"series",name:option.xAxis[0].data[index],seriesName:"MIN关联故障",seriesType:"line",value:option.series[8].data[index]};' \
                 'var lineType = param.seriesName, x = param.name, y = param.value;' \
                 '''var faultIds = globalDataSet["tab-2-chart1"][lineType][x][y].faultIds.split(',');''' \
                 "if (faultIds != null && faultIds != '' && faultIds.length > 0) {" \
                 'skipToFautlOrder(faultIds);' \
                 'return false;' \
                 '}' \
                 '}})'

            driver.execute_script(js1)
            self.log_file_out('点击单一模型图表上的点成功')
        except:
            self.log_file_out('点击单一模型图表上的点失败')

        time.sleep(3)
        try:
            Method(driver).switch_out()
            Method(driver).two_element_click("[class='layui-layer layui-layer-page']", 'layui-layer-ico')
        except:
            print('')
            pass

        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/disposableModel/data_view')]"))
        except:
            return
        time.sleep(3)

        try:
            Method(driver).click('xpath', '/html/body/div/ul/li[3]/a')
            time.sleep(2)
            Method(driver).click('id', 'tab-3-chart11')
            self.log_file_out('点击故障占比分析图表成功')
        except:
            self.log_file_out('点击故障占比分析图表失败')
        try:
            js2 = 'var aa = echarts.getInstanceByDom($("#tab-3-chart11")[0]);' \
                  'var option = aa.getOption();' \
                  ' option.series[0].data.forEach((item,index)=>{' \
                  'if( item != "NaN"){' \
                  'var param = {componentType:"series",name:option.yAxis[0].data[index],seriesName:"关联故障",seriesType:"bar",value:option.series[0].data[index]};' \
                  'var lineType = param.seriesName, x = param.name, y = param.value;' \
                  '''var faultIds = globalDataSet["tab-3-chart11"][lineType][x][y].faultIds.split(',');''' \
                  "if (faultIds != null && faultIds != '' && faultIds.length > 0) {" \
                  'skipToFautlOrder(faultIds);' \
                  'return false;' \
                  '}' \
                  '}})'

            driver.execute_script(js2)
            self.log_file_out('点击故障占比图表上的点成功')
        except:
            self.log_file_out('点击图表占比图表上的点失败')










# url = 'http://192.168.1.115:9092/darams/a?login'
# car = {
#     'E27': ['2641','2642','2643']
# }
#
# fault_pattern = {'高压供电系统':'all'}
#
# fault_object = {
#     '高压供电系统':{'高压电缆、连接器及跳线':['电缆']},
#     '辅助供电系统':['刮雨器电源'],
#     '门窗系统':'all'
# }
#
# time_sleep = 3
# wait_time = 10
#
#
# Tech().tech_fault_analysis(url,1,'里程','0','100',car,fault_pattern,time_sleep,wait_time)
