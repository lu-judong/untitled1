import os
from os import path

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException,WebDriverException
import requests
from config.log_config import logger
import time
from bin.main import Method
from bin.login import Login
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from new_selenium.test_weixiu.weixiu_config import *
from bin.select_car import deal_car


#维修规程优化效果分析
class test_technology:
    def log_file_out(self,msg):
        fo = open(r'./usecase.txt', mode='a', encoding='utf-8')
        fo.write(msg + '\r\n')
        fo.close()


    # 检查RAMS运营数据分析
    def tech(self,url,username,password,modelCode,modelName,value,remarks,start,end,average,end1,average1,lateHours,car,fault,time_sleep,wait_time):

        # option = webdriver.ChromeOptions()
        # option.add_argument("headless")
        # driver = webdriver.Chrome(chrome_options=option
        # ,executable_path=r'../apps/chromedriver.exe'
        #  )
        # driver.maximize_window()
        path_dir = os.path.dirname(path.dirname(__file__)).replace('\\', '/')
        driver = webdriver.Chrome(executable_path=r'{}/apps/chromedriver.exe'.format(path_dir))

        Login().login(url,username,password,driver)

        self.log_file_out('-----修成修制-----')

        try:
            for i in contents:
                try:
                    Method(driver).contains_xpath('click',i)
                    self.log_file_out('点击'+i+'成功')
                except Exception as e:
                    logger.debug(e)
                    self.log_file_out('点击' + i + '失败')
            time.sleep(time_sleep)
            # 点击新建得到弹框
            try:
                Method(driver).switch_out()
                Method(driver).switch_iframe(
                    driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/repairProcedure')]"))
                Method(driver).click('xpath', '//*[@id="add"]')
                time.sleep(time_sleep)
            except NoSuchElementException as e:
                self.log_file_out('点击新建按钮失败,未找到新建按钮的xpath')

            # 切换到新的模型列表
            Method(driver).switch_out()
            a = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
            Method(driver).switch_iframe('layui-layer-iframe' + a)

            #对新增指标页面进行操作
            try:
                Method(driver).input('id', 'modelCode', modelCode)
                Method(driver).input('id', 'modelName', modelName)
                Method(driver).select_down_list('id', 'modelObject', value)
                if remarks is '':
                    pass
                else:
                    Method(driver).input('id', 'remarks', remarks)
                self.log_file_out('模型录入成功')
            except Exception as e:
                logger.debug(e)

                self.log_file_out('模型录入出错')
            # 优化前里程
            try:
                Method(driver).click('xpath', '//*[@id="left-tab-1"]/a')
                Method(driver).input('xpath', '//*[@id="confMileageList0_startMileage"]', start)
                Method(driver).input('xpath', '//*[@id="confMileageList0_endMileage"]', end)
                Method(driver).select_down_list('xpath', '//*[@id="confMileageList0_averageSpeedSelect"]', average)
                self.log_file_out('优化前里程输入成功')
            except NoSuchElementException as e:
                logger.error('xpath' + '不存在！')
                self.log_file_out('优化前里程录入失败')
            except:
                self.log_file_out('优化前里程录入失败')

            # 优化后里程
            try:
                Method(driver).click('xpath','//*[@id="inputForm"]/div[1]/ul/li[2]/a')
                time.sleep(time_sleep)
                Method(driver).input('xpath','//*[@id="confMileageList1_endMileage"]',end1)
                Method(driver).select_down_list('xpath','//*[@id="confMileageList1_averageSpeedSelect"]',average1)
                self.log_file_out('优化后里程输入成功')
            except NoSuchElementException as e:
                logger.error('xpath' + '不存在！')
                self.log_file_out('优化后里程输入失败')
            except:
                self.log_file_out('优化前里程录入失败')
            # 服务故障定义
            try:
                Method(driver).click('xpath', '//*[@id="inputForm"]/div[1]/ul/li[3]/a')
                time.sleep(time_sleep)
                Method(driver).click('xpath', '//*[@id="left-tab-3"]/a')
                time.sleep(time_sleep)
                Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[2]/div/button')
                Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[2]/div/div/ul/li[1]/a')
                Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[2]/div/div/ul/li[2]/a')
                Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[2]/div/div/ul/li[3]/a')
                time.sleep(time_sleep)
                self.log_file_out('服务故障定义录入成功')
            except NoSuchElementException as e:
                logger.error('xpath' + '不存在！')
                self.log_file_out('服务故障定义录入失败')

            # 晚点时长
            try:
                Method(driver).click('xpath', '//*[@id="inputForm"]/div[1]/ul/li[4]/a')
                time.sleep(time_sleep)
                Method(driver).click('xpath', '//*[@id="left-tab-4"]/a')
                Method(driver).input('xpath', '//*[@id="confLateHoursList0_lateHours"]', lateHours)
                self.log_file_out('晚点时长写入成功')
                # 车型-车号新增
                Method(driver).click('xpath', '//*[@id="right-tab-1"]/a')
                time.sleep(time_sleep)
            except NoSuchElementException as e:
                logger.error('xpath' + '不存在！')
                self.log_file_out('晚点时长写入失败')

            # 从新进入新打开的iframe 先去最外层 在进入打开的iframe
            # try:
            #     Method(driver).switch_out()
            #     b = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
            #     Method(driver).switch_iframe('layui-layer-iframe' + b)
            #     time.sleep(time_sleep)
            # except NoSuchElementException:
            #     self.log_file_out('请选择评估对象')

            Method(driver).switch_out()
            b = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
            Method(driver).switch_iframe('layui-layer-iframe' + b)
            time.sleep(5)

            a = deal_car(driver, car)
            if a is True:
                self.log_file_out('选车成功')
            else:
                self.log_file_out('选车失败')

            # 故障模式选择页面
            Method(driver).switch_out()
            # try:
            #     c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
            #     Method(driver).switch_iframe('layui-layer-iframe' + c)
            # except NoSuchElementException as e:
            #     self.log_file_out('请选择评估对象')

            c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
            Method(driver).switch_iframe('layui-layer-iframe' + c)
            time.sleep(8)
            try:
                for key in fault:
                    if type(fault[key]).__name__ == 'dict':
                        fault_next_1 = Method(driver).contains_xpath('get', key)
                        Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_1[:-7]))

                        # 取出第二个子节点中的值
                        for i in fault[key]:
                            if type(fault[key][i]).__name__ == 'dict':
                                fault_next_2 = Method(driver).contains_xpath('get', i)
                                Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_2[:-7]))

                                # 取出第三个子节点的值
                                for m in fault[key][i]:
                                    if type(fault[key][i][m]).__name__ == 'dict':
                                        fault_next_3 = Method(driver).contains_xpath('get', m)
                                        Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_3[:-7]))
                                        # 取出第四个子节点的值
                                        for j in fault[key][i][m]:
                                            if fault[key][i][m][j] == 'all':
                                                Method(driver).click('xpath', '//*[text()=\'{}\']'.format(j))
                                                Method(driver).click('name', 'btSelectAll')
                                                Method(driver).click('xpath', '//*[@id="right-move"]')
                                            else:
                                                fault_next_4 = Method(driver).contains_xpath('get', j)
                                                Method(driver).click('xpath',
                                                                     '//*[@id= \'{}\']/i'.format(fault_next_4[:-7]))
                                                time.sleep(time_sleep)
                                                for p in fault[key][i][m][j]:
                                                    driver.find_element_by_xpath(
                                                        "//td[contains(text(),\'{}\')]/../td[1]/input".format(p)).click()
                                                    Method(driver).click('xpath', '//*[@id="right-move"]')

                                    else:
                                        Method(driver).click('xpath', '//*[text()=\'{}\']'.format(m))
                                        time.sleep(time_sleep)
                                        if fault[key][i][m] == 'all':
                                            Method(driver).click('name', 'btSelectAll')
                                            Method(driver).click('xpath', '//*[@id="right-move"]')
                                        else:
                                            for k in fault[key][i][m]:
                                                driver.find_element_by_xpath(
                                                    "//td[contains(text(),\'{}\')]/../td[1]/input".format(k)).click()
                                            Method(driver).click('xpath', '//*[@id="right-move"]')
                            else:
                                Method(driver).click('xpath', '//*[text()=\'{}\']'.format(i))
                                time.sleep(time_sleep)
                                if fault[key][i] == 'all':
                                    Method(driver).click('name', 'btSelectAll')
                                    Method(driver).click('xpath', '//*[@id="right-move"]')
                                else:
                                    for n in fault[key][i]:
                                        driver.find_element_by_xpath(
                                            "//td[contains(text(),\'{}\')]/../td[1]/input".format(n)).click()
                                        time.sleep(time_sleep)
                                    Method(driver).click('xpath', '//*[@id="right-move"]')

                    else:
                        Method(driver).click('xpath', '//*[text()=\'{}\']'.format(key))
                        time.sleep(time_sleep)
                        if fault[key] == 'all':
                            Method(driver).click('name', 'btSelectAll')
                            Method(driver).click('xpath', '//*[@id="right-move"]')
                        else:
                            for i in fault[key]:
                                # WebDriverWait(driver, 10).until(EC.element_to_be_clickable(By.XPATH, "//td[contains(text(),\'{}\')]/../td[1]/input".format(i))).click()
                                driver.find_element_by_xpath(
                                    "//td[contains(text(),\'{}\')]/../td[1]/input".format(i)).click()
                            Method(driver).click('xpath', '//*[@id="right-move"]')
                self.log_file_out('故障模型页面选择成功')
            except NoSuchElementException as e:
                logger.error('xpath' + '不存在!')
                self.log_file_out('故障模型页面选择失败')

            try:
                Method(driver).switch_out()
                # d = "layui_layer" + c
                # e = "layui_layer" + str((int(c)-1))
                # Method(driver).click('xpath','//*[@id=\'%s\']/div[3]/a[3]' % d)
                Method(driver).click('class', 'layui-layer-btn2')
                # 点击保存按钮
                time.sleep(time_sleep)
                # Method(driver).click('xpath','//*[@id=\'%s\']/div[3]/a[1]' % e)
                Method(driver).click('class', 'layui-layer-btn0')
            except NoSuchElementException as e:
                logger.error('xpath' + '不存在!')
                self.log_file_out('点击保存按钮失败')
            except WebDriverException:
                print('请录入正确的模型')
                return

            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/repairProcedure')]"))
            time.sleep(time_sleep)
            try:
                driver.find_element_by_xpath(
                    "//a[contains(text(),\'{}\')]/../../td[8]/a[3]".format(modelCode)).click()
            except WebDriverException:
                print('请录入正确的模型')
                return

            if driver.find_element_by_xpath("//a[contains(text(),\'{}\')]/../../td[5]".format(modelCode)).text == '计算异常':
                self.log_file_out('计算异常,无法打开图表页面')
            else:
                try:
                    a = WebDriverWait(driver, wait_time).until(
                        EC.text_to_be_present_in_element((By.XPATH, "//a[contains(text(),\'{}\')]/../../td[5]".format(modelCode)),
                                                         u'计算完成'))
                    if a is True:
                        logger.debug('评估成功')
                        self.log_file_out('评估成功')

                        driver.find_element_by_xpath("//a[contains(text(),\'{}\')]/../../td[8]/a[4]".format(modelCode)).click()

                        # 查看点击图表出来的页面是否存在
                        Method(driver).switch_out()
                        c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
                        try:
                            next_url = Method(driver).get_attr('id', 'layui-layer-iframe' + c, 'src')
                            status = requests.get(next_url).status_code
                            if status == 200:
                                logger.debug('图表页面获取成功')
                                self.log_file_out('图表页面获取成功')
                                driver.close()
                            elif status == 404:
                                logger.error('{}请求404'.format(next_url))
                                self.log_file_out('图表页面获取失败')
                                driver.close()
                        except Exception as e:
                            logger.error(e)
                            driver.close()
                except Exception as e:
                    logger.debug('评估时间太长,评估失败')
                    self.log_file_out('评估时间太长,评估失败')
        except:
            print(e)
            driver.close()
#
# url = 'http://192.168.1.115:9092/darams/a?login'
#
# car = {
#     'E01': ['2001', '2002'],
#     'E02': ['2061', '2062']
# }
#
# fault_pattern = {
#     '高压供电系统': 'all'
# }
#
# fault_object = {
#     '高压供电系统':{'高压电缆、连接器及跳线':['电缆']},
#     '辅助供电系统':['刮雨器电源'],
#     '门窗系统':'all'
# }
#
# time_sleep = 1
# wait_time = 10
# #
# #
# test_technology().tech(url,'111', '111', 2, '', '0', '100', 2, '200', 1, 3, car,fault_pattern,time_sleep,wait_time)