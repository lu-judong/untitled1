import os
from os import path

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
import requests
from config.log_config import logger
import time
from bin.main import Method
from bin.login import Login
from selenium.webdriver.support.ui import Select
from new_selenium.test_techm.tech_config import *
from bin.select_car import deal_car


#技术整改优化效果分析
class Tech:
    def log_file_out(self,msg):
        fo = open(r'./usecase.txt', mode='a', encoding='utf-8')
        fo.write(msg + '\r\n')
        fo.close()

    def tech_analysis(self,url,username,password,value,start,end,start1,end1,car,fault,time_sleep,wait_time):
        # option = webdriver.ChromeOptions()
        # option.add_argument("headless")
        # driver = webdriver.Chrome(chrome_options=option,                                                                executable_path=r'C:\Users\a\PycharmProjects\untitled\new_selenium\apps\chromedriver.exe')
        path_dir = os.path.dirname(path.dirname(__file__)).replace('\\', '/')
        driver = webdriver.Chrome(executable_path=r'{}/apps/chromedriver.exe'.format(path_dir))
        Login().login(url, username, password, driver)

        self.log_file_out('-----技术整改立即计算-----')
        for i in contents:
            try:
                Method(driver).contains_xpath('click',i)
                self.log_file_out('点击'+i+'成功')
            except Exception as e:
                logger.debug(e)
                self.log_file_out('点击' + i + '失败')

        time.sleep(time_sleep)
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/technicalOptimization')]"))
            Method(driver).click('id', 'calculate')
            time.sleep(time_sleep)
        except NoSuchElementException as e:
            self.log_file_out('点击立即计算按钮失败,获取不到相应的xpath')

        Method(driver).switch_out()
        a = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
        Method(driver).switch_iframe('layui-layer-iframe' + a)

        try:
            Method(driver).select_down_list('id', 'modelObject', value)
            Method(driver).input('id', 'confMileageList0_startMileage', start)
            Method(driver).input('id', 'confMileageList0_endMileage', end)
            Method(driver).input('id', 'confMileageList1_startMileage', start1)
            Method(driver).input('id', 'confMileageList1_endMileage', end1)
        except NoSuchElementException as e:
            print('模型录入错误 找不到对应的xpath')
        except:
            print('模型录入数据出错')

        if Select(driver.find_element_by_id('mileageOrDateSelect')).first_selected_option.text == '里程':
            print('里程/日期框正确')
        else:
            print('里程/日期框错误')

        if Select(driver.find_element_by_id('averageSpeedSelect')).first_selected_option.text == '260':
            print('平均时速默认值正确')
        else:
            print('平均时速默认值不正确')

        if driver.find_element_by_css_selector("[class='filter-option pull-left']").text== driver.find_element_by_css_selector("[class='btn dropdown-toggle btn-default']").get_attribute('title'):
            print('服务故障定义默认值正确')
        else:
            print('服务故障定义默认值不正确')

        if driver.find_element_by_id('confLateHoursList0_lateHours').get_attribute('value') == '3':
            print('晚点时长默认正确')
        else:
            print('晚点时长默认不正确')

        try:
            Method(driver).contains_xpath('click', '新增')
        except NoSuchElementException as e:
            print('点击新建按钮失败')

        try:
            Method(driver).switch_out()
            b = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
            Method(driver).switch_iframe('layui-layer-iframe' + b)
        except:
            print('请录入评估对象')
            return

        time.sleep(time_sleep)

        # 车型 车号新增页面
        a = deal_car(driver, car)
        if a is True:
            self.log_file_out('选车成功')
        else:
            self.log_file_out('选车失败')

        # 故障模式选择页面
        Method(driver).switch_out()
        c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
        Method(driver).switch_iframe('layui-layer-iframe' + c)
        time.sleep(time_sleep)
        try:
            for key in fault:
                if type(fault[key]).__name__ == 'dict':
                    fault_next_1 = Method(driver).contains_xpath('get', key)
                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_1[:-7]))

                    # 取出第二个子节点中的值
                    for i in fault[key]:
                        if type(fault[key][i]).__name__ == 'dict':
                            fault_next_2 = Method(driver).contains_xpath('get', i)
                            Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_2[:-7]))

                            # 取出第三个子节点的值
                            for m in fault[key][i]:
                                if type(fault[key][i][m]).__name__ == 'dict':
                                    fault_next_3 = Method(driver).contains_xpath('get', m)
                                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_3[:-7]))
                                    # 取出第四个子节点的值
                                    for j in fault[key][i][m]:
                                        if fault[key][i][m][j] == 'all':
                                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(j))
                                            Method(driver).click('name', 'btSelectAll')
                                            Method(driver).click('xpath', '//*[@id="right-move"]')
                                        else:
                                            fault_next_4 = Method(driver).contains_xpath('get', j)
                                            Method(driver).click('xpath',
                                                                 '//*[@id= \'{}\']/i'.format(fault_next_4[:-7]))
                                            time.sleep(time_sleep)
                                            for p in fault[key][i][m][j]:
                                                driver.find_element_by_xpath(
                                                    "//td[contains(text(),\'{}\')]/../td[1]/input".format(p)).click()
                                                Method(driver).click('xpath', '//*[@id="right-move"]')

                                else:
                                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(m))
                                    time.sleep(time_sleep)
                                    if fault[key][i][m] == 'all':
                                        Method(driver).click('name', 'btSelectAll')
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                                    else:
                                        for k in fault[key][i][m]:
                                            driver.find_element_by_xpath(
                                                "//td[contains(text(),\'{}\')]/../td[1]/input".format(k)).click()
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                        else:
                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(i))
                            time.sleep(time_sleep)
                            if fault[key][i] == 'all':
                                Method(driver).click('name', 'btSelectAll')
                                Method(driver).click('xpath', '//*[@id="right-move"]')
                            else:
                                for n in fault[key][i]:
                                    driver.find_element_by_xpath(
                                        "//td[contains(text(),\'{}\')]/../td[1]/input".format(n)).click()
                                    time.sleep(time_sleep)
                                Method(driver).click('xpath', '//*[@id="right-move"]')

                else:
                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(key))
                    time.sleep(time_sleep)
                    if fault[key] == 'all':
                        Method(driver).click('name', 'btSelectAll')
                        Method(driver).click('xpath', '//*[@id="right-move"]')
                    else:
                        for i in fault[key]:
                            # WebDriverWait(driver, 10).until(EC.element_to_be_clickable(By.XPATH, "//td[contains(text(),\'{}\')]/../td[1]/input".format(i))).click()
                            driver.find_element_by_xpath(
                                "//td[contains(text(),\'{}\')]/../td[1]/input".format(i)).click()
                        Method(driver).click('xpath', '//*[@id="right-move"]')
            self.log_file_out('故障模型选择成功')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在!')
            self.log_file_out('故障模型选择失败')

        try:
            Method(driver).switch_out()
            Method(driver).click('class', 'layui-layer-btn2')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在!')
            self.log_file_out('点击确定按钮失败')
        except:
            print('请录入完整的模型')
            return

        time.sleep(time_sleep)
        try:
            Method(driver).switch_out()
            Method(driver).switch_iframe(
                driver.find_element_by_xpath(
                    "//iframe[contains(@src,'/darams/a/mould/disposableModel/technicalOptimizationForm')]"))
            time.sleep(2)
            Method(driver).click('id', 'calculate')
            print('点击计算按钮成功')
        except NoSuchElementException:
            print('点击计算按钮失败')
        except:
            print('模型录入失败')

        time.sleep(wait_time)

        Method(driver).switch_out()
        try:
            c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
        except NoSuchElementException as e:
            print('请录入正确的模型')
            return

        try:
            next_url = Method(driver).get_attr('id', 'layui-layer-iframe' + c, 'src')
            status = requests.get(next_url).status_code
            if status == 200:
                logger.debug('图表页面获取成功')
                self.log_file_out('图表页面获取成功')
            elif status == 404:
                logger.error('{}请求404'.format(next_url))
                self.log_file_out('图表页面获取失败')
        except Exception as e:
            logger.error(e)

# url = 'http://192.168.1.115:9092/darams/a?login'
#
# car = {
#     'E05': ['2091', '2092']
# }
#
# fault_pattern = {'高压供电系统': {'保护接地开关': {'接地编织线': ['断裂/破损'], '闸刀刀夹': ['裂纹/断裂']}}, '辅助供电系统': {'头灯': 'all'}}
#
# fault_object = {
#     '高压供电系统': {'高压电缆、连接器及跳线': ['电缆']},
#     '辅助供电系统': ['刮雨器电源'],
#     '门窗系统': 'all'
# }
#
# time_sleep = 2
# wait_time = 10
#
#
# Tech().tech_analysis(url,2,'0','100','100','200',car,fault_pattern,time_sleep,wait_time)

