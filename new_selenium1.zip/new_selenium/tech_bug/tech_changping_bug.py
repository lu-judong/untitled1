from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException,WebDriverException
import requests
from config.log_config import logger
import time
from bin.main import Method
from bin.login import Login
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC




url = "http://192.168.1.115:9092/darams/a?login"

#维修规程优化效果分析
class test_technology:

    # 检查RAMS运营数据分析
    def tech_chang_bug(self,url,modelCode,modelName,value,remarks,start,end,average,t,car,fault,time_sleep,wait_time):

        driver = webdriver.Chrome()
        Login().login(url,'admin', 'admin', driver)
        a = requests.get(url)
        try:
            if a.status_code == 200:
                logger.debug('登录成功')
            elif a.status_code == 404:
                logger.debug('http请求404')
        except Exception as e:
            error = '错误信息\n'.format(e)
            logger.debug(error)
        Method(driver).contains_xpath('click', '运营数据统计分析系统')
        try:
            Method(driver).contains_xpath('click', '产品RAMS指标统计评估')
        except Exception as e:
            logger.debug(e)
        time.sleep(1)
        # 点击新建得到弹框
        Method(driver).switch_out()
        Method(driver).switch_iframe(
            driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/confModel')]"))
        Method(driver).click('xpath', '//*[@id="add"]')
        time.sleep(1)

        # 切换到新的模型列表
        Method(driver).switch_out()
        a = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
        Method(driver).switch_iframe('layui-layer-iframe' + a)

        #对新增指标页面进行操作
        try:
            Method(driver).input('id', 'modelCode', modelCode)
            Method(driver).input('id', 'modelName', modelName)
            Method(driver).select_down_list('id', 'modelObject', value)
            if remarks is '':
                pass
            else:
                Method(driver).input('id', 'remarks', remarks)
        except Exception as e:
            logger.debug(e)

        # 优化前里程
        try:
            Method(driver).click('xpath', '//*[@id="left-tab-1"]/a')
            Method(driver).input('xpath', '//*[@id="confMileageList0_startMileage"]', start)
            Method(driver).input('id', 'confMileageList0_endMileage', end)
            Method(driver).select_down_list('id', 'confMileageList0_averageSpeedSelect', average)
            v4 = '里程录入成功'
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在！')
            v4 = '里程录入失败'

        # 服务故障定义
        try:
            Method(driver).click('xpath', '//*[@id="inputForm"]/div[3]/ul/li[3]/a')
            time.sleep(1)
            Method(driver).click('xpath', '//*[@id="left-tab-3"]/a')
            time.sleep(1)
            Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[3]/div/button')
            Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[3]/div/div/ul/li[1]/a')
            Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[3]/div/div/ul/li[2]/a')
            Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[3]/div/div/ul/li[3]/a')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在！')

        # 晚点时长
        try:
            Method(driver).click('xpath', '//*[@id="confServiceFaultList0"]/td[3]/div/button')
            time.sleep(2)
            Method(driver).click('xpath', '//*[@id="inputForm"]/div[3]/ul/li[4]/a')
            time.sleep(1)
            Method(driver).click('xpath', '//*[@id="left-tab-4"]/a')
            Method(driver).input('xpath', '//*[@id="confLateHoursList0_lateHours"]', t)
            # 车型-车号新增
            Method(driver).click('id', 'addModel')
            time.sleep(1)
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在！')

        # 从新进入新打开的iframe 先去最外层 在进入打开的iframe
        try:
            Method(driver).switch_out()
            b = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
            Method(driver).switch_iframe('layui-layer-iframe' + b)
        except NoSuchElementException:
            v5 = '请输入评估对象'
        time.sleep(time_sleep)

        # 车型 车号新增页面
        try:
            for x in car:
                car_type = Method(driver).contains_xpath('get', x)
                Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(car_type[:-7]))
                car_num = car.get(x)
                if car_num == 'all':
                    Method(driver).click('xpath', '//*[@id= \'{}\']/i[1]'.format(car_type))
                else:
                    for i in car_num:
                        carnum = Method(driver).contains_xpath('get', i)
                        Method(driver).click('xpath', '//*[@id= \'{}\']/i[1]'.format(carnum))
            v5 = '车型-车号选择成功'

            Method(driver).click('xpath', '//*[@id="positive-right-move"]')
            Method(driver).click('xpath', '//*[@id="result-right-move"]')

            Method(driver).switch_out()
            # 这个可以点击得元素失去焦点
            # Message: unknown error: Element <a class="layui-layer-btn1">...</a> is not clickable at point (975, 498). Other element would receive the click: <a class="layui-layer-btn3">...</a>
            # Method(driver).two_element_click("[class='layui-layer-btn layui-layer-btn-']",'layui-layer-btn1')
            Method(driver).two_element_click("[class='layui-layer layui-layer-iframe my-skin']",
                                             'layui-layer-btn1')
        #
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在!')
            v5 = '车型-车号选择失败'

        # 故障模式选择页面
        Method(driver).switch_out()
        c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe my-skin']", 'times')
        Method(driver).switch_iframe('layui-layer-iframe' + c)
        time.sleep(1)
        try:
            for key in fault:
                if type(fault[key]).__name__ == 'dict':
                    fault_next_1 = Method(driver).contains_xpath('get', key)
                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_1[:-7]))

                    # 取出第二个子节点中的值
                    for i in fault[key]:
                        if type(fault[key][i]).__name__ == 'dict':
                            fault_next_2 = Method(driver).contains_xpath('get', i)
                            Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_2[:-7]))

                            # 取出第三个子节点的值
                            for m in fault[key][i]:
                                if type(fault[key][i][m]).__name__ == 'dict':
                                    fault_next_3 = Method(driver).contains_xpath('get', m)
                                    Method(driver).click('xpath', '//*[@id= \'{}\']/i'.format(fault_next_3[:-7]))
                                    # 取出第四个子节点的值
                                    for j in fault[key][i][m]:
                                        if fault[key][i][m][j] == 'all':
                                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(j))
                                            Method(driver).click('name', 'btSelectAll')
                                            Method(driver).click('xpath', '//*[@id="right-move"]')
                                        else:
                                            fault_next_4 = Method(driver).contains_xpath('get', j)
                                            Method(driver).click('xpath',
                                                                 '//*[@id= \'{}\']/i'.format(fault_next_4[:-7]))
                                            time.sleep(1)
                                            for p in fault[key][i][m][j]:
                                                driver.find_element_by_xpath(
                                                    "//td[contains(text(),\'{}\')]/../td[1]/input".format(p)).click()
                                                Method(driver).click('xpath', '//*[@id="right-move"]')

                                else:
                                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(m))
                                    time.sleep(1)
                                    if fault[key][i][m] == 'all':
                                        Method(driver).click('name', 'btSelectAll')
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                                    else:
                                        for k in fault[key][i][m]:
                                            driver.find_element_by_xpath(
                                                "//td[contains(text(),\'{}\')]/../td[1]/input".format(k)).click()
                                        Method(driver).click('xpath', '//*[@id="right-move"]')
                        else:
                            Method(driver).click('xpath', '//*[text()=\'{}\']'.format(i))
                            time.sleep(1)
                            if fault[key][i] == 'all':
                                Method(driver).click('name', 'btSelectAll')
                                Method(driver).click('xpath', '//*[@id="right-move"]')
                            else:
                                for n in fault[key][i]:
                                    driver.find_element_by_xpath(
                                        "//td[contains(text(),\'{}\')]/../td[1]/input".format(n)).click()
                                    time.sleep(1)
                                Method(driver).click('xpath', '//*[@id="right-move"]')

                else:
                    Method(driver).click('xpath', '//*[text()=\'{}\']'.format(key))
                    time.sleep(1)
                    if fault[key] == 'all':
                        Method(driver).click('name', 'btSelectAll')
                        Method(driver).click('xpath', '//*[@id="right-move"]')
                    else:
                        for i in fault[key]:
                            # WebDriverWait(driver, 10).until(EC.element_to_be_clickable(By.XPATH, "//td[contains(text(),\'{}\')]/../td[1]/input".format(i))).click()
                            driver.find_element_by_xpath(
                                "//td[contains(text(),\'{}\')]/../td[1]/input".format(i)).click()
                        Method(driver).click('xpath', '//*[@id="right-move"]')
        except NoSuchElementException as e:

            logger.error('xpath' + '不存在!')

        try:
            Method(driver).switch_out()
            # d = "layui_layer" + c
            # e = "layui_layer" + str((int(c)-1))
            # Method(driver).click('xpath','//*[@id=\'%s\']/div[3]/a[3]' % d)
            Method(driver).click('class', 'layui-layer-btn2')
            # 点击保存按钮
            time.sleep(1)
            # Method(driver).click('xpath','//*[@id=\'%s\']/div[3]/a[1]' % e)
            Method(driver).click('class', 'layui-layer-btn0')
            logger.debug('bug不存在')
        except NoSuchElementException as e:
            logger.error('xpath' + '不存在!')
            logger.debug('bug存在')

        Method(driver).switch_out()
        Method(driver).switch_iframe(
            driver.find_element_by_xpath("//iframe[contains(@src,'/darams/a/mould/confModel')]"))
        time.sleep(time_sleep)
        try:
            driver.find_element_by_xpath(
                "//a[contains(text(),\'{}\')]/../../td[9]/a[2]".format(modelCode)).click()
        except WebDriverException:
            print('请录入正确的模型')
            return

        if driver.find_element_by_xpath("//a[contains(text(),\'{}\')]/../../td[6]".format(modelCode)).text == '计算异常':
            logger.debug('计算异常')
        else:
            try:
                a = WebDriverWait(driver, wait_time).until(
                    EC.text_to_be_present_in_element(
                        (By.XPATH, "//a[contains(text(),\'{}\')]/../../td[6]".format(modelCode)),
                        u'计算完成'))
                if a is True:
                    logger.debug('评估成功')

                    driver.find_element_by_xpath(
                        "//a[contains(text(),\'{}\')]/../../td[9]/a[3]".format(modelCode)).click()

                    # 查看点击图表出来的页面是否存在
                    Method(driver).switch_out()
                    c = Method(driver).get_attr('css', "[class='layui-layer layui-layer-iframe']", 'times')
                    try:
                        next_url = Method(driver).get_attr('id', 'layui-layer-iframe' + c, 'src')
                        status = requests.get(next_url).status_code
                        if status == 200:
                            logger.debug('图表页面获取成功')
                        elif status == 404:
                            logger.error('{}请求404'.format(next_url))
                    except:
                        logger.error(e)
            except Exception as e:
                logger.debug('评估时间太长,评估失败')

url = 'http://192.168.1.115:9092/darams/a?login'
car={
    'E01,2A':['2001','2002'],
    'E02,2C1':['2061','2062']
}

fault = {
    '高压供电系统':{'保护接地开关':
                  {'接地编织线': ['断裂/破损'],
                   '闸刀刀夹': ['裂纹/断裂']}
         },
    '辅助供电系统':{'头灯':'all'}
}
test_technology().tech_chang_bug(url,'111','111',2,'','0','100',2,3,car,fault,2,10)